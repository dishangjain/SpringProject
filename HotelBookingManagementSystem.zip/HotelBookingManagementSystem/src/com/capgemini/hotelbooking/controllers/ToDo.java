package com.capgemini.hotelbooking.controllers;

public class ToDo {
	//TODO sessions and login, validating user
	//TODO showing room availability based on date (ask utkarsh)
	//TODO validate everything such that user is forced to input the number from the list
	//TODO Check in time implementation
	//TODO check out date should be after check in date, checkin and checkout f\date should be after sysdate
	//TODO validations according to length constraint in database
	//TODO implement error page properly
	//TODO implement view booking status properly
}
